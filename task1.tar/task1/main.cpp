#include "partition.h"

int main() {
	partition("test.txt", 1, 0.1);
	return 0;
}
