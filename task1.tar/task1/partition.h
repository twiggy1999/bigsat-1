#pragma once
#include <stdio.h>

int partition(const char * in, int nparts, double range);
